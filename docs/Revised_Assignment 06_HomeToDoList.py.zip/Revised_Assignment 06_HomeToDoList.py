# ------------------------------------------------- #
# Title: Assignment_06_HomeToDoList
# Description: Learning to work with functions, global and local variables, and classes
# ChangeLog: (Who, When, What)
# Susan Tadei Dev,05/24/2023,Created Script
# Susan Tadei Dev, 6/1/2023, Revised prior script
# ------------------------------------------------- #

# -- Data --#
# Declare variables and constants
strFileName = "ToDoList.txt"  # An object that represents a file
strChoice = ""  # A row of text data from the file
#objFile = None
#dicRow = {}  # A row of data separated into elements of a dictionary {Task,Priority}
#lstTable = []  # A dictionary that acts as a 'table' of rows
#strChoice = ""  # Capture the user option selection
#row = ""


# --Processing--#
class DataProcessor:
    """  Performs Processing tasks """

    @staticmethod
    def read_file_to_list_of_dictionaries(file_name):
        """ Reads data from a file into a list of dictionary rows
        :param file_name: (string) with name of file:
        :param list_of_rows: (list) you want filled with file data:
        :return: (list) of dictionary rows
        """
        list_of_dictionary_rows = []  # clear current data
        file = open(file_name, "r")
        for line in file:
            data = line.split("")
            row = {"Task": data[0].strip(), "Priority": data[1].strip(), "Number": data[2].strip()}
            list_of_dictionary_rows.append(row)
        file.close()
        return list_of_dictionary_rows

    @staticmethod
    def add_data_to_list(task, priority, list_of_rows):
        """ Write data to a list of dictionary rows

        :param task: file_name: (string) with name of task:
        :param priority: file_name: (string) with name of priority:
        :param list_of_dictionary_rows: (list) you want to add more data to:
        :return: (bool) with success status
        """
        success_status = False
        file = open(file_name, "w")
        for row in lstTable:
         file.write(row["Task"] + "," + row["Priority"] + "," + row["Number"] + "\n")
        file.close()
        success_status = True
        return success_status

    @staticmethod
    def add_data_to_list_of_dictionaries(list_of_dictionary_rows, task, priority):
            """ Add data to a list of dictionary rows

            :param list_of_dictionary_rows: (string) you want to add more data to:
            :param task: file_name: (string) with name of task:
            :param priority: file_name: (string) with name of priority:
            """

            row = {"Task": str(task).strip(), "Priority": str(priority).strip(), "Number": str(number).strip()}
            list_of_dictionary_rows.append(row)

    @staticmethod
    def remove_data_from_list_of_dictionaries(list_of_dictionary_rows, task_to_remove):
        """ Removes data from a list of dictionary rows

        :param list_of_dictionary_rows: (list) you want to remove a row from:
        :param task_to_remove: (string) with name of task in the dictionary's 'Task' key:
        :return: (list) list_of_dictionary rows, (bool) with success status
        """
        success_status = False
        row_number = 0
        for row in list_of_dictionary_rows:
            if row["Task"].lower() == task_to_remove.lower():
                list_of_dictionary_rows.remove(row)
                success_status = True
            row_number += 1
        return list_of_dictionary_rows, success_status
# Processing #

#Presentation #

class IO:

    @staticmethod
    def print_menu_items():
        """Print a menu of choices to the user

        :return: nothing
        """
        print('''
        Menu of Options
        1) Show current data.
        2) Add a new item.
        3) Remove an existing item
        4) Save Data to File
        5) Reload Data from File
        6) Exit Program
        """)
        print()
        
        @staticmethod
        def print_current_list_items(list_of_rows):
        """ Print the current items in the list of dictionaries rows

        :param list_of_rows.(list) of rows you want to display
        :return: nothing
        """
        print("The current items ToDo are: ")
        for row in list_of_rows:
            print (row["Task"] + "(" + row["Priority"] + ")")
            print("     ")
            print()
            
            @staticmethod
            def print_data_removed_status(success_status):
            """ Print the status of the task removal process

            :param success_status.(bool) status you want to display
            """
            
            if success_status:
                print("The task was removed.")
            else:
                print("I'm sorry, but I could not find that task.")
            print()
            
        @staticmethod
        def input_menu_of_choice():
        """ Gets the menu choice from the user

        :return: string
        """
        
        choice = str(input("Which option would you like to perform? [ 1 to 6] - ")).strip()
        print()
        return choice
        
        @staticmethod
        def input_task_priority():
        
            """Gets data for a dictionary row

        :return: (tuple) of strings with task and priority
        """
        task = str(input("What is the task? - ")).strip()
        priority = str(input("What is the priority? [high][low] - ")).strip()
        print()
        return task, priority
        
    lstTable = DataProcessor.read_file_to_list_of_dictionaries(strFileName)
    
    while True:  
       IO.print_menu_items()
       strChoice = IO.input_menu_choice()
       
    if strChoice.strip() == '1':
       IO.print_current_list_items(lstTable)
            continue
    elif strChoice.strip() == '2':
       tplData = IO.input_task_and_priority()
    
       DataProcessor.add_data_to_list_of_dictionaries(lstTable, tplData[0], tplData[1])
       IO.print_current_list_items(lstTable)
       continue
       
    elif strChoice == '3':
    
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = DataProcessor.remove_data_from_list_of_dictionaries(lstTable, strKeyToRemove)
         
        IO.print_data_removed_status(blnItemRemoved)
        IO.print_current_list_items(lstTable)
        continue
        
    elif strChoice == '4':
    
        IO.print_current_list_items(lstTable)
        strYesOrNo = str(input "Save this data to file? [y/n] - ")).strip().lower()
        if "y" == strYesOrNo:
            if DataProcessor.write_file_from_list_of_dictionaries(strName, lstTable):
                input("Data saved to file! Press the [Enter] key to return to menu.") 
       else:
        input("New Data was NOT Saved, but previous data still exists!" + 
              "Press the [Enter] key to return to menu.")
       continue
       
    elif strChoice == '5':        
          print("Warning: This will replace all unsaved changes. Data loss may occur!")
          strYesOrNo = input("Reload file data without saving? [y/n] - ")
          if strYesOrNo.lower() == 'y':
            lstTable.clear()
            lstTable = DataProcessor.read_file_to_list_of_dictionaries(strFileName)
            IO.print_current_list_items(lstTable)
       else:
          input("File data was NOT reloaded! Press the [Enter] key to return to menu.")
          IO.print_current_list_items(lstTable) 
       continue
        
    elif strChoice == '6'
       break # exit
           
